import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, NgForm, Validators} from "@angular/forms";
import {Router} from "@angular/router";

@Component({
  selector: 'app-add-post',
  templateUrl: './add-post.component.html',
  styleUrls: ['./add-post.component.css']
})
export class AddPostComponent implements OnInit {
  @ViewChild('postForm', { static: false }) postForm!: NgForm;

  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;

  constructor(private router: Router,private _formBuilder: FormBuilder) {

    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
  }

  ngOnInit(): void {
  }
  navigateToSuccessfulAdd(): void {
    this.router.navigate(['successfuladd'])
      .then(()=>console.log('Navigated to Successful Add'));
  }

}
