import {Component,OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup} from "@angular/forms";
import {Observable} from "rxjs";
import {map, startWith} from "rxjs/operators";
import {Options, LabelType} from "@angular-slider/ngx-slider";
import {PageEvent} from "@angular/material/paginator";

@Component({
  selector: 'app-search-property',
  templateUrl: './search-property.component.html',
  styleUrls: ['./search-property.component.css']
})
export class SearchPropertyComponent implements OnInit {


  public form: FormGroup;

  myControl = new FormControl();
  leftOptions: string[] = ['Lima', 'Trujillo', 'Huancavelica'];
  filteredOptions: Observable<string[]>;

  valuePrice: number = 1000;
  highValuePrice: number = 2000;
  optionsPrice: Options = {
    floor: 0,
    ceil: 5000,
    translate: (value: number, label: LabelType): string => {
      switch (label) {
        case LabelType.Low:
          return '<b>Min price:</b> $' + value;
        case LabelType.High:
          return '<b>Max price:</b> $' + value;
        default:
          return '$' + value;
      }
    }
  };

  valueArea: number = 50;
  highValueArea: number = 120;
  optionsArea: Options = {
    floor: 0,
    ceil: 200,
    translate: (value: number, label: LabelType): string => {
      switch (label) {
        case LabelType.Low:
          return '<b>Min area: </b>' + value+' m^2';
        case LabelType.High:
          return '<b>Max area:</b>' + value +' m^2';
        default:
          return value + ' m^2';
      }
    }
  };


  constructor(private fb: FormBuilder){
    this.form = this.fb.group({
      rating2: [4]
    });

    this.filteredOptions = this.myControl.valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value))
      );
  }
  ngOnInit():void {

  }
  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.leftOptions.filter(option => option.toLowerCase().includes(filterValue));
  }

  members: {title: string, subtitle: string, content: string, url: string}[] = [
    {title: 'S/ 1800', subtitle: 'San Isidro, Lima', content: 'Content here', url: 'https://img10.naventcdn.com/avisos/11/00/50/67/23/63/1200x1200/29572941.jpg'},
    {title: 'S/ 1400', subtitle: 'Magdalena, Lima', content: 'Content here', url: 'https://img10.naventcdn.com/avisos/11/00/50/67/23/63/1200x1200/29572941.jpg'},
    {title: 'S/ 1200', subtitle: 'Magdalena, Lima', content: 'Content here', url: 'https://img10.naventcdn.com/avisos/11/00/50/67/23/63/1200x1200/29572941.jpg'},
    {title: 'S/ 1900', subtitle: 'San Isidro, Lima', content: 'Content here', url: 'https://img10.naventcdn.com/avisos/11/00/50/67/23/63/1200x1200/29572941.jpg'},
    {title: 'S/ 1500', subtitle: 'Surco, Lima', content: 'Content here', url: 'https://img10.naventcdn.com/avisos/11/00/50/67/23/63/1200x1200/29572941.jpg'},
    {title: 'S/ 1000', subtitle: 'Comas, Lima', content: 'Content here', url: 'https://img10.naventcdn.com/avisos/11/00/50/67/23/63/1200x1200/29572941.jpg'}
  ];


}
